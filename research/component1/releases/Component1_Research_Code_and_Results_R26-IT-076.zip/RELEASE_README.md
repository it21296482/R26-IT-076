# Component 1 Research Code and Completed Results

Contains current experiment code, Component 1 Python source, the blank participant-study kit and completed evaluation summary metrics. It is a research supplement to the R26-IT-076 repository, not a standalone MERN application bundle. Use that repository for the complete app and exporter dependencies. Install research/component1/requirements.txt in a compatible Python environment.

The supplied results cover 173 completed held-out securities, 27 recorded failures and two development stocks. Per-security summaries and failure reasons are under research/component1/artifacts/paper_v3_verified/. Run experiments/aggregate_results.py from research/component1 to rebuild the aggregate tables. No new training is needed to aggregate saved metrics.

Raw vendor OHLCV histories, model weights, credentials and participant responses are not distributed. Repeating training requires lawful source data; the source manifest preserves the original cutoff and fingerprints. The participant study has not been conducted.

For anonymous review, do not cite this identifying repository URL. Follow the selected venue's anonymous-supplement policy.
