# Completed Component 1 V3 Evaluation

All planned source exports have a terminal execution record. Completed execution does not mean every eligible security fitted successfully: retain the failures and exclusions in the paper's cohort definition.

aggregate/ contains the tables and CSV statistics; per_stock/ contains the completed-security summary metrics used to check those aggregates. run_log_heldout.csv records all held-out tasks; failure_details.csv retains their exact failure reasons. export_manifest.json records all source attempts, including exclusions. The two development securities are separate in run_log.csv.

Paired tests are exploratory because securities share companies, trading dates and market events. Proxy labels are not expert-verified anomaly ground truth. Outside-event alerts are not independently confirmed false positives. Pattern frequencies are descriptive. No participant study is reported.

The SHA256SUMS file fingerprints every other archive member. Raw market histories and participant records are intentionally excluded.
